import BrainrotBattleDashboard from "@/components/brainrot-battle-dashboard"

export default function Home() {
  return <BrainrotBattleDashboard />
}
